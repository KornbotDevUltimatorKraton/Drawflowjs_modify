var tabs = [
  {
    title: "Pictures",
    content: "Pictures content"
  },
  {
    title: "Music",
    content: "Music content. Wanna see some <a href=\"#\" data-show=\"3\">Documents</a> content?"
  },
  {
    title: "Videos",
    content: "Videos content. <a href=\"#\" data-alert=\"VIDEOS!!!\">Alert videos</a>"
  },
  {
    title: "Documents",
    content: "Documents content. Wanna see some <a href=\"#\" data-show=\"1\">Music</a> content?"
  },   
];

var vue = new Vue({
  el: "#app",
  data: {
    show: 0,
    tabs
  },
  methods:{
    navigate: function(e){
      if (e.target.dataset.show) {
        e.preventDefault();
        this.show = e.target.dataset.show;
      }
    },
    alerts: function(e){
      if (e.target.dataset.alert) {
        e.preventDefault();
        alert(e.target.dataset.alert);
      }
    }
  }
});